<?php 
session_start();

if(isset($_SESSION['email']))
{

  $tableautout = array();

  $database= "projetweb";
  $db_handle = mysqli_connect('localhost', 'root', '');
  $db_found = mysqli_select_db($db_handle, $database);

  
  if($db_found)
  {
    $result = mysqli_query($db_handle, "SELECT photos_item, id_item, nom_item FROM item "); 
  }
  else 
  {
    echo "Database not found";
  }
  while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
  {
       $tableautout[] = $row;
  }
 
}
else
{
  header('Location:http://127.0.0.1/ProjetPiscineWeb/menu_principale.php');
}

?>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!DOCTYPE html>
<html>
<head>
<title>Formulaire</title>
<link rel="stylesheet" type="text/css" href="ajoutsuppitem.css">  
<script type="text/javascript">
  function popup()
  {
    alert("L'ajout de l'item a bien été effectué");
  }

</script>
</head>

<body>
   <div id="header">
      <input type="submit" value="Liste Vendeur" class="btn float-left btn-vendeur" name="ajoutitem">
    </div>
      <div id="contenu">
        <h1>Formulaire d'ajout</h1>
          <form method="post" action="">
      
            <!-- Ligne pour le Nom de l'objet --> 
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">Nom de l'objet</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="nom" placeholder="Nom de l'objet">
                </div>
            </div>

            <!-- Ligne pour l'URL de la photo --> 
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">Photo</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="photo" placeholder="Url photo">
                </div>
            </div>

            <!-- Ligne pour la description --> 
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">Description</label>
                <div class="col-sm-10">
                  <textarea class="form-control form-control-sm" name="description" rows="2"></textarea>
                </div>
            </div>

            <!-- Ligne pour l'URL de la vidéo --> 
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">Vidéo</label>
                  <div class="col-sm-10">
                  <input type="text" class="form-control" name="video" placeholder="Url video">
                  </div>
            </div>

            <!-- Ligne pour les Catégories --> 
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">Category</label>
                  <div class="col-sm-10">
                  <select name="category">
                  <option value="Livre">Livre</option>
                  <option value="Vetement">Vetement</option>
                  <option value="Chanson">Chanson</option>
                  <option value="Sport_Loisir">Sport_Loisir</option> 
                  </select>
                  </div>
            </div>

            <!-- Ligne pour la ss catégorie --> 
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">Sous-Category</label>
                <div class="col-sm-10">
                <input type="text" class="form-control form-control-sm" id="sous_category" placeholder="Sous-Category">
                </div>
            </div>

            <!-- Ligne pour le Prix --> 
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">Prix</label>
                <div class="col-sm-10">
                <input type="number" class="form-control form-control-sm" name="prix" placeholder="Prix" value="0">
                </div>
            </div>

            <!-- Ligne pour le stock --> 
            <div class="form-group row">
            <label class="col-sm-2 col-form-label">Stock</label>
              <div class="col-sm-10">
              <input type="number" class="form-control form-control-sm" name="stock" placeholder="nombre d'objet" max="500" value="0">
              </div>
            </div>

            <div class="form-group">
              <input type="submit" class="btn btn-primary" value="Ajouter" name="envoie" onclick="popup()"></input>
              
              <?php
                if (isset($_POST['envoie'])) 
                    {
                        $nom_objet =isset($_POST["nom"])? $_POST["nom"]: "";
                        $photo =isset($_POST["photo"])? $_POST["photo"]: "";
                        $description=isset($_POST["description"])? $_POST["description"]: "";
                        $video=isset($_POST["video"])? $_POST["video"]: "";
                        $category=isset($_POST["category"])? $_POST["category"]: "";
                        $sous_category=isset($_POST["sous_category"])? $_POST["sous_category"]: "";
                        $prix=isset($_POST["prix"])? $_POST["prix"]: 0;
                        $stock=isset($_POST["stock"])? $_POST["stock"]: 0;
                        $database= "projetweb";
                        $db_handle = mysqli_connect('localhost', 'root', '');
                        $db_found = mysqli_select_db($db_handle, $database);

                        if($db_found)
                        {
                          $sql = "INSERT INTO `item` (`id_item`,`nom_item`, `photos_item`, `description_item`, `video_item`, `categorie_item`, `sous_categorie`, `prix_item`, `stock_item`,`id_commande`, `email_admin`, `id_mesventes`, `email_client`) VALUES (DEFAULT,'$nom_objet', '$photo', '$description', '$video', '$category', '$sous_category', '$prix', '$stock',0,'',0,'')";
                        }
                        else 
                        {
                          echo "Database not found";
                        }

                        $result = mysqli_query($db_handle, $sql);
                    }
              ?>

            </div>

      </form>


      </div>

       <div id="conteneur">
        <?php for($i=0;$i<count($tableautout);$i++) : ?>
          <?php  require "rowObjetadmin.php"?>
        <?php endfor; ?>
      
       </div>

</body>
</html>