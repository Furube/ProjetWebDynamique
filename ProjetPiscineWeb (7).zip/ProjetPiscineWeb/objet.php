

<?php 

	$id = $_GET["id"]; 
?> 