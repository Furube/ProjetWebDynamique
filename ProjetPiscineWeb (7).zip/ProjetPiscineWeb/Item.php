
<link rel="stylesheet" type="text/css" href="Item.css">

<?php 

	$id = $_GET["id"];  

	$Article = array();

	$database= "projetweb";
	$db_handle = mysqli_connect('localhost', 'root', '');
	$db_found = mysqli_select_db($db_handle, $database);
 
	if($db_found)
	{
	  $result = mysqli_query($db_handle, "SELECT * FROM item WHERE `id_item` = $id" ); 
	}
	else 
	{
	  echo "Database not found";
	}
	while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC))
	{
	     $Article[] = $row;
	} 

?> 

<!DOCTYPE html>
<html>
<head>
	<title> Article </title>

	<!-- La navbar --> 
	<?php  require "navbar.php"?>
	<br>
	<br>

	<!-- Pour l'ensemble des articles  via le site https://bootsnipp.com/snippets/orOGB --> 
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<div class="container-fluid">
			
		<div class="card">
			<div class="row">
				<aside class="col-sm-5 border-right">
						<article class="gallery-wrap"> 
							<div class="img-big-wrap"  >

								<div class="text-center"> <br> <?php echo '<img src='.$Article[0]['photos_item'].'>' ; ?> </div>  
							</div> <!-- slider-product.// -->
							<!-- 
							<div class="img-small-wrap">
								<div class="item-gallery"> <img src="https://s9.postimg.org/tupxkvfj3/image.jpg"> </div>
								<div class="item-gallery"> <img src="https://s9.postimg.org/tupxkvfj3/image.jpg"> </div>
								<div class="item-gallery"> <img src="https://s9.postimg.org/tupxkvfj3/image.jpg"> </div>
								<div class="item-gallery"> <img src="https://s9.postimg.org/tupxkvfj3/image.jpg"> </div>
							
							-->
						</article> <!-- gallery-wrap .end// -->
				</aside>

				<aside class="col-sm-7">
					<article class="card-body p-5">
						<h3 class="title mb-3"> <?php echo $Article[0]['nom_item'] ?> </h3>

					<p class="price-detail-wrap"> 
						<span class="price h3 text-warning"> 
							<span class="num"> <?php echo $Article[0]['prix_item'] ?> </span> <span class="currency">US $</span>
						</span> 
						<span>/each </span> 
					</p>

					<!-- Description de l'article -->
					<dl class="item-property">
					  <dt> Description </dt>
					  <dd><p> <?php echo $Article[0]['description_item'] ?> </p></dd>
					</dl>

					<!-- Pour les catégorie --> 
					<?php if( $Article[0]['sous_categorie'] != "") {?>
						<dl class="param param-feature">
						  <dt>Model#</dt>
						  <dd> <?php echo $Article[0]['categorie_item'] ?> </dd>
						</dl>  

						<dl class="param param-feature">
						  <dt>Color</dt>
						  <dd>Black and white</dd>
						</dl>  
					<?php } ?>
					

					<!-- Pour les destionations --> 
					<dl class="param param-feature">
					  <dt>Delivery</dt>
					  <dd>Russia, USA, and Europe</dd>
					</dl>  <!-- item-property-hor .// -->


					<hr>
						<div class="row">
							<div class="col-sm-5">

								<!-- Pour sélectionner la quantité --> 
								<dl class="param param-inline">
								  <dt>Quantity: </dt>
								  <dd>
								  	<select class="form-control form-control-sm" style="width:70px;">
								  		<option> 1 </option>
								  		<option> 2 </option>
								  		<option> 3 </option>
								  		<option> 4 </option>
								  		<option> 5 </option>
								  		<option> 6 </option>
								  	</select>
								  </dd>
								</dl>  <!-- item-property .// -->
							</div> <!-- col.// -->
							<div class="col-sm-7">
								<dl class="param param-inline">
									  <dt>Size: </dt>
									  <dd>

									  	<!-- permet de faire l'alinéa --> 
									  	<label class="form-check form-check-inline">
										  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
										  <span class="form-check-label">SM</span>
										</label>

										<!-- permet de faire l'alinéa --> 
										<label class="form-check form-check-inline">
										  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
										  <span class="form-check-label">MD</span>
										</label>

										<!-- permet de faire l'alinéa --> 
										<label class="form-check form-check-inline">
										  <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2">
										  <span class="form-check-label">XXL</span>
										</label>
									  </dd>
								</dl>  <!-- item-property .// -->
							</div> <!-- col.// -->
						</div> <!-- row.// -->
						<hr>
						<a href="#" class="btn btn-lg btn-primary text-uppercase"> Buy now </a>
						<a href="#" class="btn btn-lg btn-outline-primary text-uppercase"> <i class="fas fa-shopping-cart"></i> Add to cart </a>
					</article> <!-- card-body.// -->
				</aside> <!-- col.// -->
			</div> <!-- row.// -->
		</div> <!-- card.// -->


	</div>
	<!--container.//-->

	<br><br><br>
	<!-- Pour la bande grise --> 
	
		<div class="container-fluid " >
			<div class="col-sm-12 border"">
				<br>
				<div class="img-big-wrap" >
						<div class="text-center">
									<iframe width="560" height="315" src="https://www.youtube.com/embed/7JH0me5eaf0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
						</div>
				</div>
				<br>
			</div>
		</div>

	<br><br><br>
		







	
	























	<!-- Le footer --> 
	<footer class="page-footer">
		<div class="container">
			<div class="row">
		
				<div class="col-lg-8 col-md-8 col-sm-12">
					<h6 class="text-uppercase font-weight-bold"> Information additionnelle</h6>
					<p>
						Ce site a été conçu dans le cadre du projet piscine 2019. Il a été conçu par les enseignants: Hina Manolo, JP Segado, Elisabeth Rendler et toute l’équipe du projet « piscine » de web dynamique. Que la force soit avec nous et bonne nage !! *bloubloublou*
					</p>

					<p>
						Une piscine est un bassin artificiel, étanche, rempli d'eau et dont les dimensions permettent à un être humain de s'y plonger au moins partiellement. Une piscine se différencie d'une cuve ou d'une baignade par ses équipements de filtration (pompe, filtre...). Il existe différents types de piscine dont les caractéristiques varient en fonction de leurs destinations  et de leur usage.
					</p>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-12">
					<h6 class="text-uppercase font-weightbold">Contact</h6>
					<p>
						37, quai de Grenelle, 75015 Paris, France <br>
						info@webDynamique.ece.fr <br>
						+33 01 02 03 04 05 <br>
						+33 01 03 02 05 04
					</p>
				</div>

			</div>
	
		<div class="footer-copyright text-center">&copy; 2019 Copyright | Droit
			d'auteur: webDynamique.ece.fr</div>
	</footer>

</head>
<body>

</body>
</html>