<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href='http://fonts.googleapis.com/css?family=Raleway:400,200' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="profiltest.css">

<div class="container">
	       <div class="col-md-12 col-xs-12" align="center">
	    			  <div class="outter"><img src='.$row['photo_vendeur'].'class="image-circle"/></div> 
            				<h1> "prenom:" <?php  ?>.$row['prenom_vendeur'].'"<br>"/h1>
            				<h1> "nom: "'.$row['nom_vendeur'].'"<br>"</h1>
        				</div>
	    			</div>
        
       				 <div class="col-md-12 col-xs-12 login_control">
                
                	<div class="control">
                    	<div class="label">"email: "'.$row['email_vendeur'].'"<br>";?></div>
                	</div>
                
        </div>
        
</div>