<?php

	session_start();


	$mail= $_SESSION['email'];
	$database= "projetweb";
	$db_handle = mysqli_connect('localhost', 'root', '');
	$db_found = mysqli_select_db($db_handle, $database);

	$sqlType = array(); 
	  
	$sql = 'SELECT type FROM `connexion` WHERE `email` ="'.$mail.'" ';  
	
	if($db_found)
	{
		$type = mysqli_query($db_handle, $sql);
	}

	//Verification que c'est bien un acheteur.
	while ($row = mysqli_fetch_array($type, MYSQLI_ASSOC))
	{
    	 $sqlType[] = $row['type'];
	} 

	//Ce n'est pas un client
	if ($sqlType[0] != "Client" )
	{
		//A rediriger vers le menu principale?
		for($i=0;$i<10;$i++)
		{
			echo "<br> Tu n'est pas un client :) <br>";	
		}

	}
	//C'est un client
	else
	{
		echo "Client <br>"; 
		//Cherche tt dans la bbd panier tt les comandes du client  
		$sql = 'SELECT id_commande FROM `panier` WHERE email_client="'.$mail.'"';  
		$result1 = mysqli_query($db_handle, $sql);
	
		$mesPaniers=array();
		$mesComandes=array();
		$tableauid=array(); 
		$tableauphoto=array();
		$tableaunom=array();
		$tableaudescrip=array();

		
		
		while ($row = mysqli_fetch_array($result1, MYSQLI_ASSOC))
		{
			//remplissage du tableau de panier 
			$mesPaniers[] = $row['id_commande'];	
		}
		
		echo count($mesPaniers);

		//Obliger d'avoir au moins un panier. 

		//Prend les items avec l'id panier correspondant 
		
			//Pour chaque paniers on va chercher le bon de comande
			foreach($mesPaniers as $value)
			{
				//print_r($value);
				$sql2 = 'SELECT id_item FROM `commande` WHERE id_panier ="'.$value.'"';
				$result2 = mysqli_query($db_handle, $sql2);

				//remplissage du tableau de comandes 
				while ($row = mysqli_fetch_array($result2, MYSQLI_ASSOC))
				{
					$mesComandes[]=$row['id_item'];
				}
		


				//Finalement on recup. tt les données l'item
				//$sql3="SELECT * FROM `item` WHERE id_commande ='";
				foreach($mesComandes as $value)
				{
					$sql3= 'SELECT * FROM item WHERE id_commande='.$value;	
					
					//remplissage du tableau de comandes 
					$result3 = mysqli_query($db_handle,$sql3); 
					
					while ($row = mysqli_fetch_array($result3, MYSQLI_ASSOC))
					{
						
						$tableauid[] = $row['id_item'];
						$tableauphoto[] = $row['photos_item'];
						$tableaunom[]= $row['nom_item'];
						$tableaudescrip[]=$row['description_item'];
					}
					
				}
			}
		

	}?>

<!DOCTYPE html>
<html>
<head>
	<title>Page Panier</title>
	<meta charset="utf-8">  
	<meta name="viewport" content="width=device-width, initial-scale=1">      
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">  
	<link rel="stylesheet" type="text/css" href="jolie.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>  
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script> 
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
</head>


<body>
	<!-- Création de la barre en haut de l'écran --> 
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

  		<a class="navbar-brand" href="menu_principal.php"> <h2> ECE Amazon </h2> </a> 
		<div class="collapse navbar-collapse" id="main-navigation">
	
			<!-- Titre de la page --> 
			<ul class="navbar-nav">             
				<li class="nav-item"><a class="nav-link" href=""> <h1> Mon panier </h1></a> </li>       
			</ul> 

		</div> 

	</nav>
	
	<?php $max_value= count($mesPaniers) ;?>
	
	<?php 
	for($i=0; $i< $max_value ; $i++)
	{	?> 
	
		<div class="container">   
              <div class="row">
                <div class="col-lg-12">
                   <div class="card bg-light">
                     <div class="thumbnail">
                        <!-- endroit où mettre les images venue de la database --> 
                        <div class="image">
				 			<?php 
				 			if(isset($tableauphoto[$i]))
							{
								echo '<img src="'.$tableauphoto[$i].'" width=300, height=200 >'; 
							}?>
						</div>

						<div class="caption">

							<br>
							<h3 class= "ItemTitre">
								<?php 
								if(isset($tableauphoto[$i]))
									{
								echo $tableaunom[$i]; 
								}?>
							 </h3>
							
							<h5 class="descrip">
								<?php if(isset($tableauphoto[$i]))
									{
								echo $tableaudescrip[$i]; 
									}
				  				?>
							</h5>

                        </div>

						 <?php 
						 if($tableauid[$i]=0)
							{
									/*a href="delete_from_vendeur.php?id=<?php echo $tableauid[$i]; ?>">Suppprimer</a>*/
							}
						  ?>
						  
                     </div>      
                  </div>
                  <br>
                </div>
            </div> 
		</div>
<?php }   ?>     
	
</body>

</html>
